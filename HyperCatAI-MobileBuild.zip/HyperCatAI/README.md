# HyperCat AI

HyperCat AI 是一个 Android 原生 AI 萌宠 Agent 项目起始版本，使用 Kotlin、Jetpack Compose 和 OpenAI-compatible Chat Completions API。

## 当前版本包含

- Android 原生 Compose 主界面
- 多萌宠切换：小猫、兔子、熊猫、狐狸、水獭
- 本地 / 在线模型连接配置
- OpenAI-compatible API 请求
- Ollama 等本地模型服务的兼容接入（需手机能访问服务端）
- 基于 Android `DisplayManager` 的辅助显示屏探测与 `Presentation` 演示入口
- 独立模型客户端，方便后续加入更多 Provider 和 Agent 工具

## 环境

- Android Studio（建议最新稳定版）
- JDK 17
- Android SDK Platform 35
- Gradle Wrapper 可由 Android Studio 首次导入时生成

## 编译

1. Android Studio 选择 Open 项目，打开本目录。
2. 等待 Gradle Sync。
3. 连接 Android 手机或启动模拟器。
4. 运行 `app`。

也可在已安装 Android SDK 的环境运行：

```bash
gradle :app:assembleDebug
```

APK 输出位置：

`app/build/outputs/apk/debug/app-debug.apk`

## 模型配置

本项目目前采用 OpenAI-compatible `/v1/chat/completions` 协议。

### Ollama 示例

在电脑运行 Ollama，并确保服务监听局域网接口。手机和电脑连接同一网络，在应用内填写：

- API 地址：`http://电脑局域网IP:11434/v1`
- 模型名称：例如 `qwen2.5:7b`
- API Key：留空

注意：`10.0.2.2` 仅适用于 Android 模拟器访问宿主机，不适用于真实手机。真实手机应填写电脑的局域网 IP。Ollama 默认监听地址和跨设备访问设置请按其官方文档配置。

### 在线模型

填写服务商提供的 OpenAI 兼容 API Base URL、模型 ID 和 API Key。不同服务商的协议兼容程度可能不同。

## 小米背屏适配说明（重要）

当前代码使用 Android 标准 `DisplayManager` 查找非主显示屏，并尝试通过 `Presentation` 显示萌宠界面。这是通用 Android 辅助屏适配，不代表已经获得小米 17 Pro / 17 Pro Max 的 HyperOS 背屏权限。

目前公开资料中，普通第三方 APK 对小米背屏的任意 UI 显示存在系统限制；社区方案可能依赖 Shizuku、LSPosed、Root 或系统内部宿主接口。此项目没有植入 Root、Xposed Hook 或绕过系统权限的代码。

后续建议按安全优先级推进：

1. 优先联系小米获取正式合作接口 / SDK。
2. 验证目标 ROM 是否将背屏暴露为普通 secondary display。
3. 若用户明确选择高级实验模式，再独立开发可选的 Shizuku 适配模块，并逐项确认命令、权限、ROM 兼容性。
4. 小米 18 Pro 上线后重新验证，不能假定 17 Pro 的实现可直接复用。

## 下一阶段开发清单

- [ ] 语音输入与 TTS
- [ ] 多 Provider 配置列表和连接测试
- [ ] 流式输出、上下文会话和本地加密密钥存储
- [ ] Agent 工具注册 / 权限确认 / 执行日志
- [ ] 萌宠素材包、动画状态机和自定义导入
- [ ] 后台服务、通知入口和快捷指令
- [ ] 小米背屏官方接口或经用户授权的适配器
- [ ] 单元测试、UI 测试、崩溃恢复与耗电优化

## 安全提示

- 不要把 API Key 提交到 Git 仓库或截图分享。
- 当前示例为方便本地调试允许 HTTP cleartext；正式发布应改为 HTTPS，并使用 Android Keystore 加密保存凭据。
- 不要把 Agent 任意工具执行权限直接交给模型。所有高风险操作都应由用户确认。


## 纯手机用户：使用 GitHub 云端编译 APK

本仓库包含 `.github/workflows/build-apk.yml`，可在 GitHub 云端编译，无需本地电脑。

1. 在手机浏览器打开 GitHub，登录并创建一个**私有**仓库，例如 `HyperCatAI`。
2. 解压项目 ZIP，将项目文件和隐藏目录 `.github` 一并上传到仓库根目录。确保 `settings.gradle.kts` 位于仓库根目录，而不是多套一层目录。
3. 打开仓库的 **Actions** 页面，选择 **Build HyperCat AI APK**。
4. 点击 **Run workflow**，等待任务完成。
5. 打开完成的工作流记录，在 **Artifacts** 区域下载 `HyperCatAI-debug-apk`。
6. 解压下载文件，安装 `app-debug.apk`。如系统提示，按需允许浏览器或文件管理器安装此来源的应用。

如果 Actions 页面没有出现工作流，先检查 `.github/workflows/build-apk.yml` 是否确实上传到仓库根目录下的对应路径。首次运行可能需要在仓库 Actions 设置中启用工作流。

### 小米背屏专项研究

- 普通 Android 应用无法假定能直接向小米背屏绘制任意界面；当前项目的 `DisplayManager` / `Presentation` 只是通用辅助屏探测。
- 社区项目 [Mi Back Screen](https://github.com/totallynotkasai/mi-back-screen) 说明其通过 Shizuku 执行受限 shell 命令来实现背屏壁纸/镜像等能力。
- [REAREye](https://github.com/killerprojecte/REAREye) 是 LSPosed / Xposed 模块路线，要求兼容框架，部分能力需要 Root。
- [OuterView](https://github.com/Orynnx/OuterView) 提供背屏卡片/壁纸相关方案，也依赖系统级模块环境。

这些是社区实验路线，不是小米官方 SDK。不要为了安装本应用就解锁 Bootloader、Root 或刷机；后续如研究 Shizuku/LSPosed，将作为独立可选模块，先说明风险并由用户主动选择。小米 18 Pro 兼容性必须在对应设备和 HyperOS 版本上重新验证。
