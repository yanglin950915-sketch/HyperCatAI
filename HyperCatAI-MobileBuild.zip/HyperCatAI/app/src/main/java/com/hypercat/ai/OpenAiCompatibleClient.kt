package com.hypercat.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object OpenAiCompatibleClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun chat(endpoint: String, apiKey: String, model: String, userMessage: String): String =
        withContext(Dispatchers.IO) {
            require(endpoint.startsWith("http://") || endpoint.startsWith("https://")) {
                "API 地址必须以 http:// 或 https:// 开头"
            }
            require(model.isNotBlank()) { "请填写模型名称" }
            val base = endpoint.trim().trimEnd('/')
            val url = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
            val messages = JSONArray()
                .put(JSONObject().put("role", "system").put(
                    "content",
                    "你是 HyperCat AI，一只友好、简洁、可靠的萌宠 AI 助手。回答使用用户的语言。"
                ))
                .put(JSONObject().put("role", "user").put("content", userMessage))
            val payload = JSONObject().put("model", model).put("messages", messages)
                .put("temperature", 0.7)
            val requestBuilder = Request.Builder().url(url)
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .header("Content-Type", "application/json")
            if (apiKey.isNotBlank()) requestBuilder.header("Authorization", "Bearer $apiKey")
            http.newCall(requestBuilder.build()).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) error("HTTP ${response.code}: ${body.take(500)}")
                val json = JSONObject(body)
                json.optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("message")?.optString("content")
                    ?.takeIf { it.isNotBlank() } ?: "模型返回了空内容。"
            }
        }
}
