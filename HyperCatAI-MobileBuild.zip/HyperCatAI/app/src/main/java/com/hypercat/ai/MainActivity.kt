package com.hypercat.ai

import android.app.Presentation
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.view.Display
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.setContent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Ink = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Accent = Color(0xFFB7F36B)

class MainActivity : ComponentActivity() {
    private var rearPresentation: PetPresentation? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HyperCatApp(
            onShowRear = { showRearPet() },
            onHideRear = { rearPresentation?.dismiss(); rearPresentation = null }
        ) }
    }

    private fun showRearPet() {
        val manager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = manager.displays.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }
        if (display == null) return
        rearPresentation?.dismiss()
        rearPresentation = PetPresentation(this, display).also { it.show() }
    }

    override fun onDestroy() {
        rearPresentation?.dismiss()
        super.onDestroy()
    }
}

private class PetPresentation(context: Context, display: Display) :
    Presentation(context, display) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(ComposeView(context).apply {
            setContent { PetFace(pet = "小猫", expression = "开心", compact = true) }
        })
    }
}

data class ChatLine(val text: String, val fromUser: Boolean)

@Composable
private fun HyperCatApp(onShowRear: () -> Unit, onHideRear: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("hypercat", Context.MODE_PRIVATE) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "http://10.0.2.2:11434/v1") ?: "") }
    var apiKey by remember { mutableStateOf(prefs.getString("apiKey", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "qwen2.5:7b") ?: "") }
    var provider by remember { mutableStateOf(prefs.getString("provider", "本地模型") ?: "本地模型") }
    var pet by remember { mutableStateOf(prefs.getString("pet", "小猫") ?: "小猫") }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("待命中") }
    val lines = remember { mutableStateListOf(ChatLine("你好！我是你的 HyperCat AI。点击萌宠，或者直接告诉我想做什么。", false)) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White, onPrimary = Ink
    )) {
        Scaffold(containerColor = Ink) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("HYPERCAT AI", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("你的口袋 AI 伙伴", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { showSettings = !showSettings }) {
                        Icon(Icons.Default.Settings, contentDescription = "设置", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PetFace(pet, if (busy) "思考" else "开心", Modifier.size(112.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("$pet · $status", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("模型：$model", color = Color.LightGray, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(onClick = onShowRear, label = { Text("尝试显示背屏") })
                            AssistChip(onClick = { pet = nextPet(pet); prefs.edit().putString("pet", pet).apply() },
                                label = { Text("换萌宠") })
                        }
                    }
                }
                if (showSettings) {
                    Spacer(Modifier.height(12.dp))
                    SettingsPanel(
                        provider, { provider = it; prefs.edit().putString("provider", it).apply() },
                        endpoint, { endpoint = it },
                        model, { model = it },
                        apiKey, { apiKey = it },
                        onSave = {
                            prefs.edit().putString("endpoint", endpoint.trim())
                                .putString("model", model.trim()).putString("apiKey", apiKey)
                                .putString("provider", provider).apply()
                            showSettings = false
                        }
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text("对话与任务", color = Color.LightGray, fontSize = 13.sp)
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(lines) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement =
                            if (line.fromUser) Arrangement.End else Arrangement.Start) {
                            Text(line.text, modifier = Modifier.widthIn(max = 310.dp)
                                .background(if (line.fromUser) Color(0xFF35452A) else Panel, RoundedCornerShape(16.dp))
                                .padding(12.dp), color = Color.White)
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f).padding(10.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                        decorationBox = { inner ->
                            if (input.isEmpty()) Text("和小猫说点什么…", color = Color.Gray)
                            inner()
                        }
                    )
                    IconButton(enabled = !busy && input.isNotBlank(), onClick = {
                        val prompt = input.trim()
                        input = ""
                        lines.add(ChatLine(prompt, true))
                        busy = true; status = "思考中"
                        scope.launch {
                            val answer = runCatching {
                                OpenAiCompatibleClient.chat(
                                    endpoint = endpoint, apiKey = apiKey, model = model,
                                    userMessage = prompt
                                )
                            }.getOrElse { "连接失败：${it.message ?: "未知错误"}\n请检查模型服务地址、网络和模型名称。" }
                            lines.add(ChatLine(answer, false))
                            busy = false; status = "待命中"
                        }
                    }) { Icon(Icons.Default.Send, contentDescription = "发送", tint = Accent) }
                }
                Spacer(Modifier.height(5.dp))
                Text("提示：本地模型服务需允许手机访问局域网地址。", color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun PetFace(pet: String, expression: String, modifier: Modifier = Modifier, compact: Boolean = false) {
    val face = when (pet) {
        "兔子" -> "૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა"
        "熊猫" -> "ʕ●ᴥ●ʔ"
        "狐狸" -> "ᵔᴥᵔ"
        "水獭" -> "ᵕ̈"
        else -> "(=^･ω･^=)"
    }
    Column(modifier.background(Color(0xFF090A0C), RoundedCornerShape(20.dp))
        .padding(if (compact) 6.dp else 12.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Text(face, color = Color.White, fontSize = if (compact) 24.sp else 27.sp, fontWeight = FontWeight.Medium)
        if (!compact) {
            Text(when (expression) { "思考" -> "···"; "开心" -> "♡"; else -> "—" },
                color = Accent, fontSize = 13.sp)
            Text(pet, color = Color.Gray, fontSize = 9.sp)
        }
    }
}

private fun nextPet(current: String) = when (current) {
    "小猫" -> "兔子"; "兔子" -> "熊猫"; "熊猫" -> "狐狸"; "狐狸" -> "水獭"; else -> "小猫"
}

@Composable
private fun SettingsPanel(
    provider: String, onProvider: (String) -> Unit,
    endpoint: String, onEndpoint: (String) -> Unit,
    model: String, onModel: (String) -> Unit,
    apiKey: String, onApiKey: (String) -> Unit,
    onSave: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
        Text("模型连接", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = provider == "本地模型", onClick = { onProvider("本地模型") }, label = { Text("本地模型") })
            FilterChip(selected = provider == "在线模型", onClick = { onProvider("在线模型") }, label = { Text("在线模型") })
        }
        SettingField("兼容 OpenAI 的 API 地址", endpoint, onEndpoint)
        SettingField("模型名称", model, onModel)
        SettingField("API Key（本地可留空）", apiKey, onApiKey)
        Text("示例：Ollama 通常使用 http://手机可访问的电脑IP:11434/v1", color = Color.Gray, fontSize = 10.sp)
        Button(onClick = onSave, modifier = Modifier.align(Alignment.End)) { Text("保存设置") }
    }
}

@Composable
private fun SettingField(label: String, value: String, onValue: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 7.dp)) {
        Text(label, color = Color.LightGray, fontSize = 11.sp)
        OutlinedTextField(value, onValue, modifier = Modifier.fillMaxWidth(),
            singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp))
    }
}
